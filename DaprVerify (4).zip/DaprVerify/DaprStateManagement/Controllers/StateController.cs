﻿using Dapr.Client;
using Microsoft.AspNetCore.Mvc;

namespace DaprStateManagement.Controllers
{
    /// <summary>
    /// Controller for managing state.
    /// </summary>
    [Route("api")]
    [ApiController]
    public class StateController : ControllerBase
    {
        private readonly DaprClient daprClient;
        private readonly ILogger<StateController> logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="StateController"/> class.
        /// </summary>
        /// <param name="daprClient">The Dapr client.</param>
        /// <param name="logger">The logger.</param>
        public StateController(DaprClient daprClient, ILogger<StateController> logger)
        {
            this.daprClient = daprClient;
            this.logger = logger;
        }

        /// <summary>
        /// Gets the state for the specified key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns>The state for the specified key.</returns>
        [HttpGet("state/{key}")]
        public async Task<ActionResult<StateCache>> GetState(string key)
        {
            try
            {
                var state = await daprClient.GetStateAsync<StateCache>("statestore", key);
                return Ok(state);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error getting state");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error getting state");
            }
        }

        /// <summary>
        /// Saves the state to the state store.
        /// </summary>
        /// <param name="stateCache">The state cache.</param>
        /// <returns>An action result.</returns>
        [HttpPost("state")]
        public async Task<ActionResult> SaveState(StateCache stateCache)
        {
            try
            {
                await daprClient.SaveStateAsync<StateCache>("statestore", stateCache.Key, stateCache);
                return Ok();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error saving state");
                return StatusCode(StatusCodes.Status500InternalServerError, "Error saving state");
            }
        }
    }

    /// <summary>
    /// Represents a state cache.
    /// </summary>
    public class StateCache
    {
        /// <summary>
        /// Gets or sets the key.
        /// </summary>
        public string Key { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
    }
}
