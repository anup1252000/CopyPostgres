﻿using Dapr.Actors.Runtime;

namespace DaprActorVerify
{
    public class CounterActor : Actor, ICounterActor
    {
        public CounterActor(ActorHost host) : base(host)
        {
        }

        public async Task<int> AddCountAsync(CancellationToken cancellationToken = default)
        {
            var currentCount = await StateManager.GetOrAddStateAsync(stateName: "count", value: 0);
            currentCount++;
            await StateManager.SetStateAsync(stateName: "count", currentCount);
            return currentCount;
        }

        public async Task<int> GetCountAsync(CancellationToken cancellationToken = default)
        {
            return await StateManager.GetStateAsync<int>(stateName: "count");
        }
    }
}
