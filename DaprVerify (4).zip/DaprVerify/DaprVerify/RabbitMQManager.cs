﻿namespace DaprVerify
{
    using RabbitMQ.Client;
    using System;

    public class RabbitMQManager
    {
        private readonly IConnection _connection;
        private readonly IModel _channel;

        public RabbitMQManager(string hostName, string userName, string password)
        {
            var factory = new ConnectionFactory()
            {
                HostName = hostName,
                UserName = userName,
                Password = password
            };

            _connection = factory.CreateConnection();
            _channel = _connection.CreateModel();
        }

        public void CreateQueue(string queueName, string exchangeName, string routingKey)
        {
            // Declare the exchange
            _channel.ExchangeDeclare(exchange: exchangeName, type: "direct");

            // Declare the queue
            _channel.QueueDeclare(queue: queueName,
                                  durable: true,
                                  exclusive: false,
                                  autoDelete: false,
                                  arguments: null);

            // Bind the queue to the exchange
            _channel.QueueBind(queue: queueName,
                               exchange: exchangeName,
                               routingKey: routingKey);
        }

        public void Close()
        {
            _channel.Close();
            _connection.Close();
        }
    }

}
