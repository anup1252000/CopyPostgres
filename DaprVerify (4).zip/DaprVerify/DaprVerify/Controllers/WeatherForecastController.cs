using Dapr;
using Dapr.Client;
using Microsoft.AspNetCore.Connections;
    using Microsoft.AspNetCore.Mvc;
    using RabbitMQ.Client;
    using System.Text;
    using System.Text.Json;

    namespace DaprVerify.Controllers
    {
        [ApiController]
        [Route("[controller]")]
        public class WeatherForecastController : ControllerBase
        {
            private static readonly string[] Summaries = new[]
            {
                "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
            };

            private readonly ILogger<WeatherForecastController> _logger;
            private readonly DaprClient _daprClient;

            public WeatherForecastController(ILogger<WeatherForecastController> logger, DaprClient daprClient)
            {
                _logger = logger;
                _daprClient = daprClient;
            }

            [HttpGet(Name = "GetWeatherForecast")]
            public IEnumerable<WeatherForecast> Get()
            {
                var factory = new ConnectionFactory() { HostName = "localhost" };
                using (var connection = factory.CreateConnection())
                using (var channel = connection.CreateModel())
                {
                    // Declare the exchange with the correct durable property
                    channel.ExchangeDeclare(
                        exchange: "hello_direct_exchange",
                        type: "direct",
                        durable: true // Ensure this matches the existing exchange declaration
                    );

                    Console.WriteLine("Exchange declared successfully.");
                }
                return Enumerable.Range(1, 5).Select(index => new WeatherForecast
                {
                    Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                    TemperatureC = Random.Shared.Next(-20, 55),
                    Summary = Summaries[Random.Shared.Next(Summaries.Length)]
                })
                .ToArray();
            }

        //// Define your subscription method for 'myqueue'
        //[Topic("azure-servicebus-pubsub", "myqueue")]
        //[HttpPost("/Subscribe/myqueue")]
        //public IActionResult SubscribeToQueue([FromBody] string message)
        //{
        //    // Process the message
        //    Console.WriteLine($"Received message: {message}");
        //    return Ok();
        //}

        [HttpPost("publish")]
            public async Task<IActionResult> PublishMessage([FromBody] string message)
            {
                try
                {
                List<string> messages = new List<string>(); 
                    _logger.LogInformation("Publishing message: {Message}", message);
                    for (int i = 0; i < 10; i++)
                    {
                        messages.Add(message);
                    }
                    //await _daprClient.PublishEventAsync("azure-servicebus-pubsub", "ganeshparvati", message);
                    await _daprClient.BulkPublishEventAsync("azure-servicebus-pubsub", "ganeshparvati", messages);
                _logger.LogInformation("Message published successfully");
                    return Ok("Message published");
                    //return Ok("Message published");
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error publishing message");
                    return StatusCode(500, "Error publishing message");
                }
            }

            [HttpPost("publish1")]
            public async Task<IActionResult> Publish1Message([FromBody] Employee employee)
            {
                try
                {
                    List<Employee> messages = new();
                    _logger.LogInformation("Publishing message: {Message}", JsonSerializer.Serialize(employee));
                    for (int i = 0; i < 10; i++)
                    {
                        messages.Add(employee);
                    }
                    await _daprClient.BulkPublishEventAsync("azure-servicebus-pubsub", "myqueue", messages);
                    _logger.LogInformation("Message published successfully");
                    return Ok("Message published");
                    //return Ok("Message published");
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error publishing message");
                    return StatusCode(500, "Error publishing message");
                }
            }

        }

        public class Employee
        {
            public int Id { get; set; }
            public required string Name { get; set; }

        }
    }
