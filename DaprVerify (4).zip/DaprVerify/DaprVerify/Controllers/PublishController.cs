﻿using Dapr.Client;
using Microsoft.AspNetCore.Mvc;

namespace DaprVerify.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PublishController : ControllerBase
    {
        private readonly DaprClient _daprClient;
        private readonly ILogger<PublishController> _logger;
        private readonly RabbitMQManager _rabbitMQManager;

        public PublishController(DaprClient daprClient, ILogger<PublishController> logger)
        {
            _daprClient = daprClient;
            _logger = logger;
            _rabbitMQManager = new RabbitMQManager("localhost", "guest", "guest");
        }

        [HttpPost("publish")]
        public async Task<IActionResult> PublishMessage([FromBody] string message)
        {
            try
            {
                _logger.LogInformation("Publishing message: {Message}", message);

                // Dynamically create a queue and bind it to the exchange
               // _rabbitMQManager.CreateQueue("dynamic-queue", "test", "");

                await _daprClient.PublishEventAsync("rabbitmq-pubsub", "hello", message);
                _logger.LogInformation("Message published successfully");
                return Ok("Message published");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error publishing message");
                return StatusCode(500, "Error publishing message");
            }
        }
    }
}
